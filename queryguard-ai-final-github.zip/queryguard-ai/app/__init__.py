"""Streamlit application package."""
