"""QueryGuard package module."""
